#!/usr/bin/perl
use CGI qw(param);

my $post_text1 = param("text1");

print "Post variable(text1 filed) = ".$post_text1;

