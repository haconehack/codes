/*
 * xHTTPd daemon.
 * Copyright(c) x90c all rights reserved.
 * Email: geinblues@gmail.com 
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/stat.h>

#include "main.h"

/*
 * xHTTPd ���� �ʱ�ȭ 
*/
int 
init_httpd( int port, int max_user )
{
    int tid = 0;
    int server_err = 0;
    int err = 0;

    if( port <= 0 || port >= 65535 )
        port = PORT;
    
    if( max_user <= 0 || max_user >= 128 )
        max_user = MAX_USER;

    /* HTTPd ����ü �ʱ�ȭ */
    HTTPd.port = port;
    HTTPd.max_user = max_user;
    HTTPd.max_thread = MAX_MASTER_THREAD;
    sprintf( HTTPd.path, HTTPd.htdocs_path );

    CLIENT.current_user = 0;    // ������ ī��Ʈ = 0 
   
    /* ���� ������ �ʱ�ȭ ( TCP/IP Listening ) */
    err = init_server_thread( &HTTPd.sock_fd, &HTTPd.sock_id, HTTPd.port, HTTPd.max_user);
    if( err < 0 )
        return -1;

    printf( "xHTTPd Pthread << Total: %d x %d>> !\n", 
            MAX_MASTER_THREAD, MAX_CLIENT_THREAD );
   
    /* Mutex Object Initialized */
    pthread_mutex_init( &HTTPd.lock, NULL );
    pthread_mutex_init( &CLIENT.lock, NULL );
   
    /* ���� ������ ���� */
    for( tid = 0; tid < MAX_MASTER_THREAD; tid++ )
    { 
        pthread_create( &HTTPd.thread[ tid ], NULL, server_thread, ( void * ) tid );
    }
  
    close( HTTPd.sock_fd );
    pthread_exit( NULL );

    return 0;
}

/* 
 * �ΰ� �ʱ�ȭ 
*/
int
init_logger( int level, char *filename )
{

}

/*
 * Ŭ���̾�Ʈ ������
*/
void
*client_thread( void *tid )
{
    char *rbuf = NULL;    // 1310720bytes ( maximum: 1280kb, 1.25 mb)
    char post_data[ MAX_POST_DATA ]; 
    int bytes = 0, recv_index = 0, res = 0;
    int sock_res = 0, post_data_res = 0;
    int i = 0;
    int csock_id = 0;
    int j = 0;
    struct sockaddr_in csock_fd;
    socklen_t socklen = 0;

    if(CLIENT.sock_id[ (int) tid] == -1 ){
//        printf("[o] client thread - TID: %d\n", tid);
        CLIENT.sock_id[ (int) tid] = -2;
        CLIENT.thread[ (int) tid] = pthread_self();
    }

    while(1){           // Thread Reusing loop begin.
        bytes = 0;
        recv_index = 0;
        res = 0;
        sock_res = 0;
        post_data_res = 0;
        i = 0;
        j = 0;
        socklen = 0;
        rbuf = NULL;

        memset( post_data, 0, sizeof(post_data));
    
        for(j = 0; j < MAX_CLIENT_THREAD * MAX_MASTER_THREAD; j++){
            if( CLIENT.sock_id[ (int) tid] == -2 ){
                memset( ( void * ) &csock_fd, 0, sizeof( struct sockaddr_in ) );
                CLIENT.sock_id[ (int) tid] = 
                    accept( HTTPd.sock_id, ( struct sockaddr * ) &csock_fd, &socklen );
                csock_id = CLIENT.sock_id[(int)tid];
                
                if( csock_id == -1 ){
                    continue;
                }

                break;
            }
        }

        /* Ŭ���̾�Ʈ ������ ���� */
        printf("server_thread[%d]:: Ŭ���̾�Ʈ ������. [ %d ] \n", tid, csock_id );

        
        rbuf = malloc( RBUF_SIZE + 1 );
        
        if( !rbuf )
        {
            fprintf( stderr, "client_thread:: rbuf �޸� �Ҵ� ����!\n" );
            goto out;
        }
    
        memset( rbuf, 0, RBUF_SIZE + 1 );

        CLIENT.current_user++;

        printf( "Ŭ���̾�Ʈ ���� ID: %d\n", csock_id );
    

        /* 1����Ʈ�� ������ ��û ��� ó�� */
        while(1)
        {
            if( fdopen( csock_id, "r" ) < 0 )
            {
                fprintf( stderr, "��ȿ���� ���� ���ϵ�ũ��Ʈ!\n" );
                goto out;
            }

            sock_res = sock_recv( csock_id, ( char * ) ( rbuf + recv_index ) , 1);
            if( sock_res == -1 || sock_res == 0)
            {
                goto out;
            }

            if( recv_index >= RBUF_SIZE - 1 || recv_index < 0){
                goto out;
            }
       
            if( ( *( rbuf + recv_index ) == '\n' && 
                *( rbuf + (recv_index - 1) ) == '\n' ) || 
                ( *( rbuf + recv_index ) == '\n' && 
                *( rbuf + (recv_index - 1) ) == '\r' &&
                *( rbuf + ( recv_index - 2 ) ) == '\n' && 
                *( rbuf + ( recv_index - 3 ) ) == '\r' ) )
                {

                if( *( rbuf + 0 ) == 'P' && *( rbuf + 1 ) == 'O' &&
                    *( rbuf + 2 ) == 'S' && *( rbuf + 3 ) == 'T' &&
                    *( rbuf + 4 ) == ' ' ){
                    post_data_res = sock_recv( csock_id, (char *)&post_data, 
                                               sizeof(post_data) - 1 );
                    if( post_data_res == -1 )
                    {
                        goto out;
                    }
                    else
                    {    
                        post_data[post_data_res] = '\x00';
                    }
                }
            
                sprintf( rbuf, "%s%s", rbuf, post_data );
                *( rbuf + strlen( rbuf ) ) = '\x00';

//              printf("REQ[%d][%d] -%s-\n", tid, csock_id, rbuf);
                res = token_tags( rbuf, csock_id ); // HTTP ����Ÿ ó�� 

                /* ���� */
                if( res == -1 || res == -2 || res == -3 || res == -4 | res == -5 )
                {
                    fprintf( stderr, "client_thread:: token_tags() ���� ��ȯ!\n" );
                    goto out;
                }
                else if( res == 0 )  // HTTP 1.0 Ŭ��¡.
                {
                    goto out;
                } 
                else if( res == 1 )
                {
                    goto out;      // QUIT ���ɾ� ó�� �ʿ�!
                } 
            }

            recv_index++;
        }

out:
        if( rbuf != NULL )
        {
            free( rbuf );
            rbuf = NULL;
        }

        close_sock( &CLIENT, csock_id );

        CLIENT.sock_id[(int)tid] = -2;

    }   // end of thread reusing loop

}

/* 
 * ���� ������ 
*/
void 
*server_thread( void *tid )
{
    char *recv_data = NULL;
    char temp[ 128 ];
    pthread_t thread;
    int csock_id = 0;
    int p = 0;
    int i = 0;

    memset( temp, 0, 128 );

    /* creating client threads */
    for( i = 0; i < MAX_CLIENT_THREAD; i++)
    {
        CLIENT.sock_id[i] = -1;
        if(pthread_create( &CLIENT.thread[i], NULL, client_thread, ( void * ) i ) != 0)
        {
            fprintf( stderr, "Thread creation fail!\n");
        }
    }

    printf("Listening[%d]: %d/TCP - xHTTPd ( Max Client Threads: %d )\n",
            tid,
            HTTPd.port,
            MAX_CLIENT_THREAD );

}

/*
 * HTML ����Ÿ �з� �� ó�� 
*/
int 
token_tags( char *MIME, int sock_id )
{
    struct _PARSED_MIME *pPMIME = NULL;
    static char MIME_response[] = 
    {
        "HTTP/%s %d %s\r\n"
        "Date: %s\r\n"
        "Server: xHTTPd/0.1-0 (Linux)\r\n"
        "Accept-Ranges: bytes\r\n"
        "Content-Length: %d\r\n"
        "Connection: Close\r\n"
        "Content-Type: %s; charset=%s\r\n"
    };
    static char MIME_response_no_file[] =
    {
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">"
        "<html><head>"
        "<title>404 Not Found</title>"
        "</head><body>"
        "<h1>Not Found</h1>"
        "<p>The requested URL /%s was not found on this server.</p>"
        "<hr>"
        "<address>xHTTPd/0.1-0 (Linux) Server at %s Port 80</address>"
        "</body></html>\r\n\r\n"
    };

    static char response[ MAX_RESPONSE ];
    static char res_status[ 12 ];
    static char version[ 4 ];
    static char now[ 64 ];
    static char content_type[ 12 ];
    static int status = 200;
    static unsigned int html_file_size = 0, total_bytes = 0;
    static char html_filename[ MAX_URL_FILENAME ];
    static char html_file_data[ MAX_HTML_FILE_DATA ];
    
    static struct _USER_ARGV user_argv[ MAX_USER_ARGV ]; 
    static int user_argc = 0;
    static int i = 0;

    char *perl_stdout = NULL;
    static int perl_res = 0;
   
    static int split_res = 0;
    static int res = 0;
    static int pas_res = 0;

    static int cookie_i = 0;

#ifdef _DEBUG
    printf("token_tags::MIME=-%s-\n", MIME);
#endif

    memset( version, 0, sizeof( version ) );
    memset( content_type, 0, sizeof( content_type ) );
    memset( response, 0, sizeof( response ) );
    memset( res_status, 0, sizeof( res_status ) );
    memset( html_filename, 0, MAX_URL_FILENAME );
    memset( html_file_data, 0, MAX_HTML_FILE_DATA );

    /* �޸� ( ��ó�� ��� ���� ) */
    perl_stdout = malloc( MAX_PERL_STDOUT );
    
    if( !perl_stdout )
    {
        fprintf( stderr, "token_tags:: perl_stdout �޸� �Ҵ� ����!\n" );
        res = -1;
        goto out;
    }
    memset( perl_stdout, 0, sizeof( perl_stdout ) );
    
    /* ���Ź��� MIME ��� �Ľ� */
    pPMIME = malloc( sizeof( struct _PARSED_MIME ) );

    if( !pPMIME )
    {
        fprintf( stderr, "token_tags:: pPMIME �޸� �Ҵ� ����\n");
        res = -2;
        goto out;
    }
    
    memset( ( void * ) pPMIME, 0, sizeof( struct _PARSED_MIME ) );
    pas_res = parse_data( pPMIME, MIME, strlen( MIME ), " \n" );
  
    /* �޸� �Ҵ�, �޼ҵ�, ȣ��Ʈ �Ľ� ���� */ 
    if( pas_res == -1 || pas_res == -2 || pas_res == -3 || pas_res == 4 )
    {
        status = 403;
        sprintf( res_status, "Fobidden" );
        fprintf( stderr, "token_tags::parse_data() �޸��Ҵ�/�޼ҵ�/Host �Ľ� ����!\n");
        res = -3;
        goto HTTP_SEND;
    }
    else
    {
        status = 200;
        sprintf( res_status, "OK" );
    }

    switch( pPMIME->method.type )
    {
        case METHOD_GET:
            printf( "�޼ҵ� GET\n" );
            break;
        case METHOD_POST:
            printf( "�޼ҵ� POST\n" );
            break;
        case METHOD_HEAD:
            printf( "�޼ҵ� HEAD\n" );
            break;
        case METHOD_UNKNOWN:
            printf( "�޼ҵ� UNKNOWN\n" );
            break;
    }

    switch( pPMIME->method.version )
    {
        case VERSION_1_0:
            sprintf( version, "1.0" );
            printf( "���� 1.0\n" );
            break;
        case VERSION_1_1:
            res = 1;
            sprintf( version, "1.1" );
            printf( "���� 1.1\n" );
            break;
        case VERSION_UNKNOWN:
            printf("���� UNKNWON\n" );
            break;
    }
   
    switch( pPMIME->command1_1 )
    {
        case COMMAND_QUIT:
            printf("QUIT\n");
            sock_send( sock_id, "Connection Closed.\n\n", 19 );
            close_sock( &CLIENT, sock_id );
            
            res = -4;
            goto out;        
            break;
    }

    memset( ( void * ) response, 0, sizeof( response ) );
    memset( ( void * ) now, 0, sizeof( now ) );
    get_timestamp( now );
  
    /* ������ �Ķ��Ÿ ��� ( ex. ?var=val&var2=val2 ) */
    user_argc = get_argv_url( pPMIME, ( struct _USER_ARGV * )&user_argv[ 0 ] );

    /* �޸� �Ҵ�/ARGV var_name/ARGV var_value ���� */
    if( user_argc == -1 || user_argc == -2 || user_argc == -3 )
    {
        user_argc = 0;
    }

    /* ���ϸ� �и� ( URL ���� ) */ 
    split_res = split_filename_url( pPMIME, ( char * )&html_filename );
   
    if( split_res == -1 || split_res == -2 || split_res == -3  || 
        split_res == -4 || split_res == -5 )
    {
        fprintf( stderr, "token_tags:: split_filename_url() ����!\n" );
        html_file_size = NO_FILE;
    } 
    else 
    {
        html_file_size = read_file( html_filename, ( char * )&html_file_data );
    }

#ifdef _DEBUG
    printf("html_file_size = %d\n", html_file_size);
#endif
   
    if( html_file_size == NO_FILE )
    {
        status = 404;
        sprintf( res_status, "Not Found\0" );
        pPMIME->content_type = CONTENT_TYPE_HTML;
        sprintf( html_file_data, MIME_response_no_file, 
                 html_filename, pPMIME->host.ipaddr );
        html_file_size = strlen( html_file_data );
    }

    switch( pPMIME->content_type )
    {
        case CONTENT_TYPE_HTML:
            sprintf( content_type, "text/html" );
            break;
        case CONTENT_TYPE_JPG:
            sprintf( content_type, "image/jpg" );
            break;
        case CONTENT_TYPE_GIF:
            sprintf( content_type, "image/gif" );
            break;
        case CONTENT_TYPE_PNG:
            sprintf( content_type, "image/png" );

        case CONTENT_TYPE_TIFF:
            sprintf( content_type, "image/tiff" );
            break;
        case CONTENT_TYPE_APP_X_WWW_FORM_URLENCODED:
            printf("content_type www url encoded!\n");
            sprintf( content_type, "text/html" );
            break;
        default:
            sprintf( content_type, "text/html" );
    }

    /* �� ��ũ��Ʈ ���� */
    if( ( ( pPMIME->content_type == CONTENT_TYPE_HTML && 
            strncmp( pPMIME->ext, "pl", 2 ) == 0  ) || 
        ( pPMIME->content_type == CONTENT_TYPE_APP_X_WWW_FORM_URLENCODED &&
          strncmp( pPMIME->ext, "pl", 2 ) == 0 ) ) && perl_stdout != NULL ) 
    {
        perl_res = do_perl( html_filename, user_argc, 
                            ( struct _USER_ARGV * )&user_argv, 
                            perl_stdout, pPMIME );
        
        /* �޸��Ҵ� ����, popen ����, MAX_PERL_STDOUT �ʰ� ���� */ 
        if( perl_res == -1 || perl_res == -2 || perl_res == -3 )
        {
           fprintf( stderr, "token_tags:: �� ó�� ����!\n" );
           res = -4;
           goto out;
        }
        else 
        {
#ifdef  _DEBUG
            printf("perl_stdout=-%s-\n", perl_stdout);
#endif
            memset( html_file_data, 0 , MAX_HTML_FILE_DATA );
            html_file_size = perl_res;
            printf("[!]\n");
            memcpy( html_file_data, perl_stdout, html_file_size ); 
        }
    }
    
    sprintf( response, MIME_response, version, status, res_status,
             now, html_file_size, content_type, pPMIME->lang );

    if( *(pPMIME->cookie[0].var) != '\x00' )
    {
        sprintf( response, "%sSet-Cookie: %s=%s", response,
              pPMIME->cookie[0].var, pPMIME->cookie[0].val );

        for( cookie_i = 1; cookie_i < MAX_COOKIE; cookie_i++ )
        {
            if( *(pPMIME->cookie[cookie_i].var) == '\x00' )
            {
                break;
            }
                sprintf( response, "%s; %s=%s", response, 
                      pPMIME->cookie[cookie_i].var,
                      pPMIME->cookie[cookie_i].val );
        }
        sprintf( response, "%s path=/\r\n", response );
    }

    sprintf( response, "%s\r\n", response );

#ifdef _DEBUG
    printf( "-%s-\n", response );
#endif

    total_bytes = strlen( response ) + html_file_size;
    memcpy( ( response + strlen(response) ), html_file_data, html_file_size );

#ifdef _DEBUG
    printf("bytes = %d %d\n", strlen(response), strlen(response) + html_file_size );
    printf("res=%s\n", response);
#endif
HTTP_SEND:
        if( sock_send( sock_id, response,  total_bytes ) == -1 )
        {
            res = -5; 
        }


#ifdef _DEBUG 
    printf( "URL: %s\n", pPMIME->method.url );
    printf( "HOST: %s\n", pPMIME->host.ipaddr );
    printf( "PORT: %d\n", pPMIME->host.port );
#endif

out:
    
    if( perl_stdout != NULL && res != -4 )
    {
        free( perl_stdout );
        perl_stdout = NULL;
    }
    if( pPMIME && res != -2 )
    {
        if( pPMIME->method.url != NULL )
        {
            free( pPMIME->method.url );
            pPMIME->method.url = NULL;
        }
        if( pPMIME->host.ipaddr != NULL )
        { 
            free( pPMIME->host.ipaddr );
            pPMIME->host.ipaddr = NULL;
        }
    }
    
    if( pPMIME != NULL )
    { 
        free( pPMIME );
        pPMIME = NULL;
    }

    return res;
}

/*
 * ������ �Ķ��Ÿ ��� ( URL �κ��� ) 
*/
int
get_argv_url( struct _PARSED_MIME *pPMIME, struct _USER_ARGV *user_argv )
{
    char *str1 = NULL, *str2 = NULL;
    char *token = "=";
    char *token_and = "&";
    char *p = NULL;
    char *url = NULL;
    int url_len = 0;
    int argv_index = 0;
    int res = 0;

//    printf("get_argv_url::-%s-\n", pPMIME->method.url );

    if( pPMIME->method.url == NULL )
    {
        fprintf( stderr, "get_argv_url:: URL �� ���Դϴ�!\n" );
        return -1;
    }
    else
    {
        url_len = strlen( pPMIME->method.url );
        url = malloc( url_len + 1 );
        
        if( !url )
        {
            fprintf( stderr, "get_argv_url:: �޸� �Ҵ� ����!\n" );
            return -2;
        }
    }

    memcpy( ( void * ) url, pPMIME->method.url, url_len );
    *( url + url_len ) = '\x00';

    if( ( str1 = strstr( url, "?" ) ) != NULL )
    {
        str1 += 1;
        
        for( argv_index = 0; argv_index < MAX_USER_ARGV; argv_index++ )
        {
            str1 = strtok_r( str1, token, &p );
            
            if( str1 ){
                if( strlen( str1 ) >= MAX_USER_VARNAME - 1 ){
                    res = -3;
                    goto out;
                }

                sprintf( ( user_argv + argv_index )->var_name, str1 );
                str2 = strtok_r( NULL, token_and, &p );
          
                if( str2 )
                {
                    if( strlen( str2 ) >= MAX_USER_VARVALUE )
                    {
                        res = -4;
                        goto out;
                    }

                    sprintf( ( user_argv + argv_index )->var_value, str2 );
                    str1 = 
                     ( str2 + ( strlen( ( user_argv + argv_index )->var_value ) + 1 ) );
                    str2 = NULL;
                }
                else
                {
                    break;
                }

            }
            else
            {
                break;
            }
        }
    }

out:
    if( url )
    {
        free( url );
        url = NULL;
    }

    if( res < 0 )
    {
        return res;
    }

    return argv_index;
}

/*
 * ���ϸ� ��� ( URL �� ���� )
*/
int 
split_filename_url( struct _PARSED_MIME *pPMIME, char *filename )
{
    char *str1 = NULL, *str2 = NULL, *p = NULL;
    char *token = ".", *end_token = "\x00";
    char *url = NULL;
    int url_len = 0;
    int res = 0;

    if( pPMIME->method.url == NULL )
    {
        fprintf( stderr, "split_filename_url:: URL�� ���Դϴ�!\n" );
        return -1;
    } 
    else
    {
        url_len = strlen( pPMIME->method.url );
        url = malloc( url_len + 1 );
            
        if( !url )
        {
            fprintf( stderr, "get_argv_url:: �޸� �Ҵ� ����!\n" );
            res = -2;
            goto out;
        }
    }

    memcpy( url, pPMIME->method.url, url_len );
    *( url + url_len ) = '\x00';

    memset( pPMIME->ext, 0, sizeof( pPMIME->ext ) );

    if( url != NULL )
    {
        if( *( url ) == '/' &&
            *( url + 1 ) == '\x00' )
        {
            sprintf( filename, "%s/index.html", HTTPd.path);

            pPMIME->content_type = CONTENT_TYPE_HTML;
        }
        else if( strncmp( url, "http:", 5 ) == 0 ||
                 strncmp( url, "ftp:", 4 ) == 0 ||
                 strncmp( url, "https:", 6) == 0 )
        {
            fprintf( stderr, "split_filename_url:: ���������� ���� �� �� �����ϴ�!");
            res = -2;
            goto out;
        }
        else
        {
            /* Ȯ���ڰ� �ִ� ���ϸ��� �Ľ� */
            str1 = ( pPMIME->method.url + 1 );

            if( ( strlen( HTTPd.path) + strlen ( str1 ) + strlen( "index.html" ) + 1) 
                    >= MAX_URL_FILENAME )
            {
                fprintf( stderr, "split_filename_url:: URL �� �ʹ� ��ϴ�!\n" );
                res = -3;
                goto out;
            }

            if( ( str1 = strtok_r( str1, token, &p ) ) != NULL )
            {
                if( ( str2 = strtok_r( NULL, end_token, &p ) ) != NULL )
                {
                    if( strncmp( str2, "html", 4 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "html\0" );
                    }
                    else if( strncmp( str2, "htm", 3) == 0 )
                    {
                        sprintf( pPMIME->ext, "htm\0" );
                    }
                    else if( strncmp( str2, "jpg", 3 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "jpg\0" );
                    }
                    else if( strncmp( str2, "gif", 3 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "gif\0" );
                    }
                    else if( strncmp( str2, "png", 3 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "png\0" );
                    }
                    else if( strncmp( str2, "tiff", 4 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "tiff\0" );
                    }
                    else if( strncmp( str2, "txt", 3 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "txt\0" );
                    }
                    else if( strncmp( str2, "pl", 2 ) == 0 )
                    {
                        sprintf( pPMIME->ext, "pl\0" );
                    }
                   
                    if( ( strlen( HTTPd.path ) + strlen( str1 ) + 
                          strlen( pPMIME->ext ) + 1 ) >= MAX_URL_FILENAME )
                    {
                        fprintf( stderr, "split_filename_url:: URL �� �ʹ� ��ϴ�!\n" );
                        res = -4;
                        goto out;
                    }
                    else{
                        sprintf( filename, "%s/%s.%s\0", HTTPd.path, str1, pPMIME->ext );
                    }
                } 
                else{       // Ȯ���ڰ� ���� ���� ���� ( ���� ���丮 ... )
                    sprintf( filename, "%s/%s/index.html\0", HTTPd.path, str1 );
                }
            }
        }
    }
    else
    {
        fprintf( stderr, "split_filename_url:: URL ���� ���ϸ��� �����ϴ�!\n" );
        res = -5;
    }

out:

    if( url )
    {
        free ( url );
        url = NULL;
    }

    return res;
}

/*
 * ���� �б�
*/
unsigned int
read_file( char *filename, char *data )
{
    FILE *fp;
    unsigned int file_size = 0;
    struct stat st;

    if( ( fp = fopen( filename, "r" ) ) == NULL )
    {
        fprintf( stderr, "read_file() %s!\n", filename );
        return NO_FILE;
    }

    if( stat( filename, &st ) == -1)
    {
        return NO_FILE;
    }
    
    file_size = fread( data, 1, st.st_size, fp );
    fclose(fp);
    
    return file_size - 1;
}

/*
 * Ÿ�� ������ ���ڿ� ����
*/
void
get_timestamp( char *times )
{
    struct tm *t = NULL;
    long now = 0;

    now = time( ( time_t * ) NULL );
    t = gmtime( ( time_t * ) &now );

    sprintf(times, "%d. %d. %d %d:%d:%d %s\0", t->tm_year + 1900,
            t->tm_mon + 1, t->tm_mday, t->tm_hour % 12, t->tm_min,
            t->tm_sec, t->tm_zone);

}

/*
 * �ñ׳� ����
*/
void 
no_signal()
{

//    signal( SIGKILL, SIG_IGN );
//    signal( SIGINT,  SIG_IGN);
    signal( SIGTRAP, SIG_IGN );
    signal( SIGABRT, SIG_IGN );
    signal( SIGSEGV, SIG_IGN );
    signal( SIGCHLD, SIG_IGN );
    signal( SIGCONT, SIG_IGN );
    signal( SIGSTOP, SIG_IGN );
    signal( SIGTSTP, SIG_IGN ) ;
    signal( SIGTTIN, SIG_IGN );
    signal( SIGTTOU, SIG_IGN );
    signal( SIGALRM, SIG_IGN );
    signal( SIGFPE, SIG_IGN );
    signal( SIGHUP, SIG_IGN );
    signal( SIGILL, SIG_IGN );
    signal( SIGPIPE, SIG_IGN );
    signal( SIGQUIT, SIG_IGN );
    signal( SIGTERM, SIG_IGN );

}

/* 
   /etc/xHTTPd.conf < "htdocsPath=/usr/local/xHTTPd/htdocs" 
*/
int configuration()
{
    FILE *fp;
    char type[32];
    char filename[98];
    char buf[129];
    int i = 0;
    char c = '\x00';
    int bytes = 0;
    struct stat cstat;

    /* Read config file. */
    if( ( fp = fopen("/etc/xHTTPd.conf", "r" ) ) == NULL )
    {
        fprintf( stderr, "configuration:: can't open /etc/xHTTPd.conf file\n" );
        return -1;
    }

    memset( buf, 0, sizeof(buf) );
    memset( type, 0, sizeof(type) );
    memset( filename, 0 , sizeof(filename) );

    /* HTTPd.htdocs_path memory allication */
    if( (bytes = fread( buf, 1, sizeof(buf), fp )) == 0 )
    {
        fprintf( stderr, "configuration:: not found htdocsPath config type\n" );
        return -2;
    }
    
    buf[bytes - 1] = '\x00';

    sscanf( buf, "%s %s", &type, &filename );

    if( strncmp( type, "htdocsPath", 10 ) != 0 )
    {
        fprintf( stderr, "htdocsPath not found in /etc/xHTTPd.conf\n" );
        fclose( fp );
        return -3;
    }

    printf("\n\t- Configuration file\t: /etc/xHTTPd.conf\n");
    printf("\n\t- Installed Path\t: %s\n", filename );
    
    if( strlen( filename ) >=  (sizeof(HTTPd.htdocs_path) - 1) )
    {
        fprintf( stderr, "\nhtdocsPath is too long. check your /etc/xHTTPd.conf\n" );
        fclose( fp);
        return -4;
    }
    
    memset( HTTPd.htdocs_path, 0, sizeof( HTTPd.htdocs_path ) );
    sprintf( HTTPd.htdocs_path, "%s\0", filename );

    fclose( fp );

    if( lstat( filename, &cstat ) != 0 )
    {
        fprintf( stderr, "\n\tWarnning: htdocs Path(%s) not found.\n\n", filename );
        return -5;
    } 

    return 0;
}

/* 
 * EntryPoint 
*/
int
main( int argc, char *argv[] )
{
    int i = 0;

    /*
    if( configuration() != 0 )
    {
        fprintf( stderr, "\n##### you need setup /etc/xHTTPd.conf and "
                         "also prefix dir! #####\n\n" );
        return -1;
    }
    */
    sprintf(HTTPd.htdocs_path, "./htdocs");
    
    no_signal();

    init_httpd( PORT, MAX_USER );
    init_logger( LOG_LEVEL_ALERT, "access_log" );
    
    while(1) {
       sleep( 60 );
    }
}


