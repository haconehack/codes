/*
 * xHTTPd daemon.
 * Copyright(c) x90c all rights reserved.
 * Email: geinblues@gmail.com
*/

int set_logformat( int level )
{

}

int write_log( char *logdata )
{

}

