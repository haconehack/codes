#!/bin/bash
aclocal
autoheader
autoconf 
automake --copy --add-missing -f

